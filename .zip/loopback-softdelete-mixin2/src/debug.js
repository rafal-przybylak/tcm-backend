import debug from 'debug';

export default (name = 'soft-delete') => debug(`loopback:mixins:${name}`);
