'use strict';

module.exports = function(Userdata) {

};
