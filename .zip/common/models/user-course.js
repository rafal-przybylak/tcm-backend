'use strict';

module.exports = function(UserCourse) {

};
