module.exports = function(Storage) {
    
    };