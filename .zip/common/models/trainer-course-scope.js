'use strict';

module.exports = function(Trainercoursescope) {

};
