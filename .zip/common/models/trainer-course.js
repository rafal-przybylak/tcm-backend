'use strict';

module.exports = function(TrainerCourse) {

};
