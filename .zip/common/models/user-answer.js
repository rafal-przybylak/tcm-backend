'use strict';

module.exports = function(Useranswer) {

};
