'use strict';

module.exports = function(Coursescope) {

};
