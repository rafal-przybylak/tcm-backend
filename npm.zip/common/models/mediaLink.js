'use strict';

module.exports = function (MediaLink) {

};
